Thank you for downloading my font.

I know it ain't perfect, far from it, but
part of the reason was my inexperience in
creating fonts and slight rush, because I
spent the last few days entirely in front
of my PC in order to create this.

I personally think this could've ended up
looking much worse. You're free to change
things up in there, the family's licensed
under the SIL Open Font License.

Email: mail@pprmint.de
Twitter: https://twitter.com/npprmint

Thanks again and have fun with my font w/
an awfully long name, MintAlternative!

┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┤･ω･)ﾉ├┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┴

Nick / pprmint.